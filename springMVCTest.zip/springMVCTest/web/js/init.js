$(function () {

    var params = {
        "database":"iq",
        "name":"zhangsan"
    }
    var func = myCallBack;
    alert(basePath+"11111")
    url=basePath+"/hello.action"
    requestDataAjax(params, url, func)

});

function myCallBack(data){
    var queryData = data.data;
    for (var i=0;i<queryData.length;i++)
    {
        $("#myId").append("<div>"+queryData[i].cityName+"\n"
        +queryData[i].cityid+"\n"+ queryData[i].user+"\n"+queryData[i].ps+"\n"+"</div>+<hr/>")
    }

}
function requestDataAjax(params, url, func) {
    var result;
        $.ajax({
        url : url,
        type : "POST",
        data : JSON.stringify(params),
        dataType : "json",
        async : false,
        timeout: 60000,
        contentType : "application/json;chartset=UTF-8",
        success : function (data) {
            alert(data)
            result = data;
            func(result);
        },
        erro : function () {
            alert(111)
            $.error("request data error");
        }
    });

}