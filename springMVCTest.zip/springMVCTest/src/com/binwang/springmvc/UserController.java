package com.binwang.springmvc;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import sun.org.mozilla.javascript.internal.json.JsonParser;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.HashMap;

@Controller//<bean id="" class="UserController">
public class UserController {

    @RequestMapping("hello.action")
    public void hello(HttpServletRequest request, HttpServletResponse response) throws IOException {

        JSONObject jsonObject = getJsonObject(request);
        String database = jsonObject.getString("database");
        HashMap<String, String> map = new HashMap<>();
        JSONArray jsonArray = new JSONArray();
        for (int i=0;i<4;i++)
        {
            JSONObject jsonChild = new JSONObject();
            jsonChild.put("cityid","1");
            jsonChild.put("cityName","zhjiang");
            jsonChild.put("user","xiaohu");
            jsonChild.put("ps","1111");
            jsonArray.add(jsonChild);
        }
        JSONObject finalJson = new JSONObject();
        finalJson.put("data",jsonArray);
        System.out.println(database);
        sendDataToView(finalJson,response);

    }

    private void sendDataToView(JSONObject jsonObject,HttpServletResponse response) throws IOException {
        response.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out = response.getWriter();
        out.print(jsonObject);
        out.flush();
        out.close();
    }

    public JSONObject getJsonObject(HttpServletRequest request){
        try {
            InputStreamReader in = new InputStreamReader(request.getInputStream(),"UTF-8");
            BufferedReader bufferedReader = new BufferedReader(in);
            StringBuffer stringBuffer = new StringBuffer();
            String str;
            while((str = bufferedReader.readLine())!=null)
            {
                stringBuffer.append(str);
            }
            return JSONObject.parseObject(stringBuffer.toString());
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
