package com.binwang.springmvc;

import com.binwang.model.User;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.validation.BindException;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractCommandController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.crypto.Data;
import java.text.SimpleDateFormat;

public class CommandController extends AbstractCommandController {

    public CommandController(){
        this.setCommandClass(User.class);
    }
    @Override
    protected ModelAndView handle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, BindException e) throws Exception {

        ModelAndView mv = new ModelAndView();
        User user = (User) o;
        mv.addObject("user",user);
        mv.setViewName("index");
        return mv;
    }

    @Override
    protected void initBinder(HttpServletRequest request, ServletRequestDataBinder binder) throws Exception {
        binder.registerCustomEditor(Data.class,
                new CustomDateEditor(new SimpleDateFormat("yyyy-mm-dd"),true));
    }

}
