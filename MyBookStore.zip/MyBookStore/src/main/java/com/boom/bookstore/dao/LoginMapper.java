package com.boom.bookstore.dao;

import com.boom.bookstore.model.SimpleUser;

public interface LoginMapper {

   void insertSimpleUser(SimpleUser User);
}
