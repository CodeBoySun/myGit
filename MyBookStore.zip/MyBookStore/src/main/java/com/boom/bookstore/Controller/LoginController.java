package com.boom.bookstore.Controller;

import com.boom.bookstore.model.SimpleUser;
import com.boom.bookstore.service.LoginService;
import com.boom.bookstore.tools.SimpleUserFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/index")
public class LoginController {

    @Resource
    private LoginService loginService;

    @RequestMapping("/login.action")
    public ModelAndView loginMain(HttpServletRequest request){
        SimpleUser simpleUser = SimpleUserFactory.createSimpleUser(request);
        loginService.insertSimpleUser(simpleUser);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("successLogin");
        mv.addObject("msg","login successful");
        return  mv;
    }

}
