package com.boom.bookstore.util;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;


public class mySqlSessionFactory {

    private static SqlSessionFactory sqlSessionFactory;
    private mySqlSessionFactory(){}
    public static SqlSession getSqlSeesion() throws IOException {
        InputStream in = Resources.getResourceAsStream("SqlMapConfig.xml");
        sqlSessionFactory = new SqlSessionFactoryBuilder().build(in);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        return sqlSession;
    }
}
