package com.boom.bookstore.service.impl;

import com.boom.bookstore.dao.LoginMapper;
import com.boom.bookstore.model.SimpleUser;
import com.boom.bookstore.service.LoginService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
@Service("loginService")
public class LoginServiceImpl implements LoginService {

    @Resource
    private LoginMapper loginMapper;
    @Override
    public void insertSimpleUser(SimpleUser simpleUser) {
        
        loginMapper.insertSimpleUser(simpleUser);
    }

    public LoginMapper getLoginMapper() {
        return loginMapper;
    }

    public void setLoginMapper(LoginMapper loginMapper) {
        this.loginMapper = loginMapper;
    }
}
