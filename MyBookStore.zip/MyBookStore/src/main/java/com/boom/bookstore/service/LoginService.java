package com.boom.bookstore.service;

import com.boom.bookstore.model.SimpleUser;


public interface LoginService {

    public void insertSimpleUser(SimpleUser simpleUser);
}
