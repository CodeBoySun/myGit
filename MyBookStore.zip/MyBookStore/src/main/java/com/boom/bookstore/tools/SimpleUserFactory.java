package com.boom.bookstore.tools;

import com.boom.bookstore.model.SimpleUser;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
@Component
public class SimpleUserFactory {

    public static SimpleUser createSimpleUser(HttpServletRequest request){
        String username=request.getParameter("username");
        String password=request.getParameter("password");
        String age=request.getParameter("age");
        String sex=request.getParameter("sex");
        SimpleUser simpleUser = new SimpleUser();
        simpleUser.setPassword(password);
        simpleUser.setUsername(username);
        simpleUser.setAge(Integer.parseInt(age));
        simpleUser.setSex(sex);
        return simpleUser;
    }
}
